import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Google Account',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: GoogleAccountPage(),
    );
  }
}

class GoogleAccountPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(241, 243, 249, 250),
          title: Row(
            children: [
              Icon(Icons.close),
              SizedBox(width: 8),
              Text('Cuenta de Google'),
            ],
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.help),
              onPressed: () {
                // Acción al presionar el icono de ayuda
              },
            ),
            IconButton(
              icon: Icon(Icons.search),
              onPressed: () {
                // Acción al presionar el icono de búsqueda
              },
            ),
            IconButton(
              icon: Icon(Icons.account_box),
              onPressed: () {
                // Acción al presionar el icono de perfil
              },
            ),
          ],
          bottom: TabBar(
            tabs: [
              Tab(text: 'Página principal'),
              Tab(text: 'Información personal'),
              Tab(text: 'Datos y privacidad'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ListView(
              padding: EdgeInsets.all(16),
              children: [
                ListTile(
                  title: Text('Tu cuenta está protegida'),
                  subtitle: Text(
                      'La verificación de seguridad revisó tu cuenta y no encontró acciones recomendadas'),
                  trailing: Icon(Icons.check_circle,
                      size: 50), // Icono de check a la derecha
                ),
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Ver detalles',
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 12,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                ListTile(
                  title: Text('Verificación de privacidad'),
                  subtitle: Text(
                      'Elige la configuración de privacidad indicada para ti con esta guía paso a paso'),
                  trailing: Icon(Icons.g_mobiledata,
                      size: 70), // Icono de G a la derecha
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16, bottom: 8),
                  child: Text(
                    'Realizar la Verificación de privacidad',
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 12,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),

                Divider(),
                Text(
                  '¿Buscas otra información?',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                    fontWeight: FontWeight.normal,
                  ),
                ),
                ListTile(
                  leading: Icon(Icons.search),
                  title: Text('Buscar cuenta de Google'),
                ),
                ListTile(
                  leading: Icon(Icons.help),
                  title: Text('Tus datos'),
                ),
                ListTile(
                  leading: Icon(Icons.feedback),
                  title: Text('Enviar comentarios'),
                ),
                SizedBox(
                    height:
                        16), // Espacio entre el contenido y el texto "Más información"
                Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Text(
                              'Solo tú puedes ver esta configuración. También puedes revisar la configuración de Maps, la Búsqueda o cualquier servicio de Google que uses con frecuencia. y la seguridad de tus datos ',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.g_mobiledata_outlined,
                            color: Colors.black,
                            size: 70,
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Mas informacion ',
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Icon(
                          Icons.help,
                          color: Colors.blue,
                          size: 16,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            Center(
                child: Text('Contenido de la pestaña "Información personal"')),
            Center(child: Text('Contenido de la pestaña "Datos y privacidad"')),
          ],
        ),
      ),
    );
  }
}
